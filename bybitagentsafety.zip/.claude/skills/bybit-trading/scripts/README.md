# `scripts/` — the `bybit-sign` signing helper

This folder will hold **`bybit-sign`**, the confirmation-gated signing helper
that sits between the agent and the Bybit V5 API. It is the mechanical
enforcement point for every safety guarantee in the parent `SKILL.md`.

**Not yet implemented.** Build it to the spec in
[`docs/signing-helper-spec.md`](../../../../docs/signing-helper-spec.md).

## What it does (summary — the spec is authoritative)

- **Holds the credentials.** Keys live in a keystore only the signer's OS user
  can read. The agent has no key material to print or misuse.
- **Signs reads freely, gates writes.** `GET` is signed and sent immediately.
  Every `POST` requires a human-issued, operation-bound confirmation.
- **Binds one CONFIRM to one operation.** The confirmation card is rendered from
  the exact bytes to be signed (`op_hash`); a mismatch, reuse, expiry, or
  modified request is refused. Confirmation is read from `/dev/tty`, never from
  model context.
- **Testnet by default; mainnet is explicit and logged**, expiring after 24h.
- **Never emits secrets** — no API secret, PEM contents, `param_str`, or
  `X-BAPI-*` headers in any output or log.
- **Fails closed** on every ambiguity.

## Planned CLI surface

```
bybit-sign init [--env testnet|mainnet] [--rsa]   # interactive key setup
bybit-sign request GET  <path> [k=v ...]          # signs & sends a read
bybit-sign intent  POST <path> <body.json>        # registers op, prints card
bybit-sign request POST <path> <body.json>        # signs & sends IFF confirmed
bybit-sign enable-mainnet | disable-mainnet       # env control (interactive)
```

## Build constraints (from the spec)

- Target ~150–200 lines; no dependencies beyond `cryptography` + stdlib.
- Separate OS user for the keystore/state; the agent's uid cannot read keys or
  write signer state (self-checked at startup; mainnet refused if violated).
- Hard denylist on withdraw endpoints regardless of confirmation.
- **Build/dev seats use testnet keys only** — no live mainnet keys on this side
  of the wall (project doctrine §5). This seat does not hold a live key.
